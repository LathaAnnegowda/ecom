package utility;

public class Propertyfiles {
	
    public static final String URL = "https://www.amazon.in/";

    public static final String Username = "lathaa.hsn@gmail.com";

    public static final String Password = "Benaka123*";

    public static final String Path_TestData = "C:\\Users\\Ashitha Hosamane\\eclipse-workspace\\Ecom\\src\\Test Data";

    public static final String File_TestData = "TestData.xlsx";


}
