package pageobject;

public class HomePage {

	String Searchbox="xpath://*[@id=\"twotabsearchtextbox\"]";
	String Searchresult="xpath://*[@id=\"search\"]/div[1]/div[1]/div/span[4]/div[1]/div[1]/div/span/div/div/span/a/div/img";
	String Buyyingoptions="xpath://*[@id=\"buybox-see-all-buying-choices-announce\"]";
	String Addtocart="xpath://*[@id=\"a-autoid-6\"]/span/input";
	String Loginlink="xpath://*[@id=\"nav-link-accountList\"]/span[1]";
}
