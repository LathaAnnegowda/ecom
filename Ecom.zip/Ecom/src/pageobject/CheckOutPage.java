package pageobject;

public class CheckOutPage {

}
